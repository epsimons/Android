package com.example.project3;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.*;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    public final static String EXTRA_MESSAGE = "MESSAGE";
    private ListView obj;
    DBHelper_USERS userDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userDB = new DBHelper_USERS(this);
        ArrayList array_list = userDB.getAllUsers();
        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1, array_list);
        // Create the database
        SQLiteDatabase inventoryDB = openOrCreateDatabase("inventory",MODE_PRIVATE,null);

        obj = (ListView) findViewById(R.id.usernameEntry);
        obj.setAdapter(arrayAdapter);
        
        Button button = findViewById(R.id.submitButton);
        button.setOnClickListener(mButtonClickListener);


    }

    // Create an anonymous implementation of OnClickListener
    private View.OnClickListener mButtonClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            // Test that the button click is read
            //Toast.makeText(MainActivity.this, "Button clicked", Toast.LENGTH_LONG).show();
            username = findViewById(R.id.usernameEntry) ;
            password = findViewById(R.id.passwordEntry);
            //getUserDBValues(username, password);
            Cursor resultSet = db.rawQuery("Select " + username + "," + password + "from users",null);
            resultSet.moveToFirst();
            String getUsername = resultSet.getString(0);
            String getPassword = resultSet.getString(1);

        }
    };




}