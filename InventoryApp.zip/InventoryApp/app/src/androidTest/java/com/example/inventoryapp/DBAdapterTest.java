package com.example.inventoryapp;

import junit.framework.TestCase;

public class DBAdapterTest extends TestCase {

    public void testGetUserPassCheck() {
    }

    public void testOpen() {
    }

    public void testClose() {
    }
}